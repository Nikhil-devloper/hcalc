let fatForAge = [
    { age: '39', male: '8-19', female: '21-32' },
    { age: '59', male: '11-21', female: '23-33' },
    { age: '79', male: '13-24', female: '24-35' },
]

module.exports = fatForAge;


/*

let fatForAge = [
    { age: '20', male: '8.5', female: '17.7' },
    { age: '25', male: '10.5', female: '18.4' },
    { age: '30', male: '12.7', female: '19.3' },
    { age: '35', male: '13.7', female: '21.5' },
    { age: '40', male: '15.3', female: '21.5' },
    { age: '45', male: '16.4', female: '22.2' },
    { age: '50', male: '18.9', female: '25.2' },
    { age: '55', male: '20.9', female: '26.3' }
]


*/